age - age
sex - sex
cp - chest pain type (4 values) -> chest pain type
trestbps - resting blood pressure -> resting bp s
chol - serum cholestoral in mg/dl -> cholesterol
fbs - fasting blood sugar > 120 mg/dl -> fasting blood sugar
restecg - resting electrocardiographic results (values 0,1,2) -> resting ecg
thalach - maximum heart rate achieved -> max heart rate
exang - exercise induced angina -> exercise angina
oldpeak - oldpeak = ST depression induced by exercise relative to rest
slope - the slope of the peak exercise ST segment -> ST slope
ca - number of major vessels (0-3) colored by flourosopy
thal - thal: 0 = normal; 1 = fixed defect; 2 = reversable defect

The names and social security numbers of the patients were recently removed from the database, replaced with dummy values.

Duplicated entries? 753